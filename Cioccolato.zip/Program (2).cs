﻿

// NOTA: si raccomanda di usare questo template anche se non lo si capisce completamente.

using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

namespace cioccolato
{

    class Program
    {
        static void Main(String[] args)
        {
            //StreamReader streamReader = new StreamReader(Console.OpenStandardInput());
            //StreamWriter streamWriter = new StreamWriter(Console.OpenStandardOutput());
            // decommenta le due righe seguenti se vuoi leggere/scrivere da file
            StreamReader reader = new StreamReader("C:\\Users\\Tecnico\\Desktop\\input.txt");
            StreamWriter writer = new StreamWriter("C:\\Users\\Tecnico\\Desktop\\output.txt");


            int T = Convert.ToInt32(reader.ReadLine());
            for (int i = 1; i <= T; ++i)
            {
                reader.ReadLine();
                string[] str = reader.ReadLine().Split(" ");
                long N = Convert.ToInt64(Convert.ToInt64(str[0]));
                long M = Convert.ToInt64(Convert.ToInt64(str[1]));
                long K = Convert.ToInt64(Convert.ToInt64(str[2]));

                long risposta = 0;


                // INSERISCI IL TUO CODICE QUI
                for (; K > 0; K--)
                {
                if (N > M)
                    N--;
                else if (N == M)
                {
                    if(N != 1)
                    M--;

                }
                else if (N < M)
                    M--;
                    Console.WriteLine("test{0} fatto", K);
                }

                risposta = N * M;                


                writer.Write($"Case #{i}: ");
                writer.WriteLine($"{risposta}");
            }

            reader.Close();
            writer.Close();
        }

    }
}