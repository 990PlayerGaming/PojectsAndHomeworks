﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace compitoTV
{
    class TV
    {
        bool _acceso = false;
        int _volume = 15;
        bool _mute = false;

        public int volumeP
        {
            get
            {
                if (_volume < 100)
                    _volume++;
                return _volume / 10;
            }
        }
        public int volumeM
        {
            get
            {
                if (_volume > 0)
                    _volume--;
                return _volume / 10;
            }
        }
        public int volume
        {
            get { return _volume; }
        }
        public bool acceso
        {
            get 
            {
                if (_acceso)
                    _acceso = false;
                else
                    _acceso = true;
                return _acceso;
            }
        }

        public bool mute
        {
            get
            {
                _mute = !_mute;
                return _mute;
            }
        }
    }
}
