﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace compitoTV
{
    class TV
    {
        bool _acceso = false;
        int _volume = 15;
        int _volumeB = 15;

        public int volumeP
        {
            get { return _volume; }
            set
            {
                if(_volume < 100)
                _volume++;
            }
        }

        public int volumeM
        {
            get { return _volume; }
            set
            {
                if(-_volume > 0) 
                    _volume--;

            }
        }

        public bool acceso
        {
            get 
            {
                if (_acceso == true)
                    _acceso = false;
                else
                    _acceso = true;
                return !_acceso;
            }
        }
    }
}
