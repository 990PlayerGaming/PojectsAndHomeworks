﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace compitoTV
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Schermo schermo = new();
        TV tv = new();
        private DispatcherTimer timer;

        bool c = false;
        public MainWindow()
        {
            InitializeComponent();
            schermo.Show();
            #region ControlloChiusura
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += Timer_Tick;
            timer.Start();
            #endregion
        }

        private void ButAcc_Click(object sender, RoutedEventArgs e)
        {
            if (!tv.acceso)
            {
                schermo.mVideo.IsEnabled = IsEnabled;
                schermo.mVideo.Source = Video.Canale();

                schermo.mVideo.Play();  
            }
            else
                schermo.mVideo.IsEnabled = false;
        }

        private void ButUp_Click(object sender, RoutedEventArgs e)
        {
            Video.aumCanale();
        }

        private void ButDown_Click(object sender, RoutedEventArgs e)
        {
            Video.dimCanale();
        }

        private void ButVup_Click(object sender, RoutedEventArgs e)
        {
            schermo.mVideo.IsEnabled = IsEnabled;
            schermo.mVideo.Volume = tv.volumeP;

        }

        private void ButVDown_Click(object sender, RoutedEventArgs e)
        {
            schermo.mVideo.IsEnabled = IsEnabled;
            schermo.mVideo.Volume = tv.volumeM;

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (!IsLoaded)
            {
                schermo.Close();
            }
            else if (!schermo.IsLoaded)
            {
                Close();
            }
        }
    }
}
