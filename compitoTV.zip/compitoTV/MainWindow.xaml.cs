﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace compitoTV
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Schermo schermo = new();
        TV tv = new();
        private DispatcherTimer timer;
        private DispatcherTimer timer0;
        private DispatcherTimer timer1;
        private DispatcherTimer timer2;
        private DispatcherTimer timer3;

        int d;
        bool c = false;
        public MainWindow()
        {
            InitializeComponent();
            schermo.mVideo.IsMuted = true;

            schermo.boxCanale.Opacity = 0;

            schermo.Show();
            #region CreazioneTimer
            timer = new();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += Timer_Tick;
            timer.Start();
            timer0 = new();
            timer0.Interval = TimeSpan.FromMilliseconds(40);
            timer0.Tick += AumOpac;

            timer1 = new();
            timer1.Interval = TimeSpan.FromMilliseconds(40);
            timer1.Tick += DimOpac;

            timer2 = new();
            timer2.Interval = TimeSpan.FromMilliseconds(40);
            timer2.Tick += AumOpac1;

            timer3 = new();
            timer3.Interval = TimeSpan.FromMilliseconds(40);
            timer3.Tick += DimOpac1;
            #endregion
        }

        private void ButAcc_Click(object sender, RoutedEventArgs e)
        {
            if (tv.acceso)
            {
                schermo.mVideo.IsMuted = false;
                schermo.mVideo.IsEnabled = true;
                schermo.mVideo.LoadedBehavior = MediaState.Manual;
                schermo.mVideo.Source = new Uri(Video.Canale());

                schermo.mVideo.Play();
                UpdateLayout();
            }
            else
            {
                schermo.mVideo.IsMuted = true;
                schermo.mVideo.IsEnabled = false;
                schermo.mVideo.Source = null;
            }
        }

        private void ButUp_Click(object sender, RoutedEventArgs e)
        {
            schermo.mVideo.Volume = tv.volumeP;
            schermo.boxVol.Text = Convert.ToString(tv.volume);
            timer2.Start();
        }
        private void ButDown_Click(object sender, RoutedEventArgs e)
        {
            schermo.mVideo.Volume = tv.volumeM;
            schermo.boxVol.Text = Convert.ToString(tv.volume);
            timer2.Start();
        }

        private void ButVup_Click(object sender, RoutedEventArgs e)
        {
            d = Video.aumCanale();
            schermo.mVideo.Source = new Uri(Video.Canale());

            schermo.mVideo.Play();
            UpdateLayout();
            timer0.Start();

        }

        private void ButVDown_Click(object sender, RoutedEventArgs e)
        {
            d = Video.dimCanale();
            schermo.mVideo.Source = new Uri(Video.Canale());

            schermo.mVideo.Play();
            UpdateLayout();
            timer0.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (!IsLoaded)
            {
                schermo.Close();
            }
            else if (!schermo.IsLoaded)
            {
                Close();
            }
        }
        private void AumOpac(object sender, EventArgs e)
        {
            schermo.boxCanale.Opacity += 0.05;
            schermo.boxCanale.Text = d.ToString();
            if (schermo.boxCanale.Opacity >= 1)
            {
                timer0.Stop();
                timer1.Start();
            }

        }
        private void DimOpac(object sender, EventArgs e)
        {
            
            schermo.boxCanale.Opacity -= 0.03;
            if (schermo.boxCanale.Opacity <= 0)
            {
                timer1.Stop();

            }

        }

        private void butMute_Click(object sender, RoutedEventArgs e)
        {
            schermo.mVideo.IsMuted = tv.mute;
            if(!tv.mute)
                schermo.boxVol.Text = "🔇";
            else
                schermo.boxVol.Text = "🔊";
            if (tv.mute) { }
            timer2.Start(); 
        }

        private void AumOpac1(object sender, EventArgs e)
        {
            schermo.boxVol.Opacity += 0.05;
            if (schermo.boxVol.Opacity >= 1)
            {
                timer2.Stop();
                timer3.Start();
            }
        }
        private void DimOpac1(object sender, EventArgs e)
        {
            schermo.boxVol.Opacity -= 0.03;
            if (schermo.boxVol.Opacity <= 0)
            {
                timer3.Stop();

            }
        }
    }
}