﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Runtime.CompilerServices;
using System.Windows.Shapes;

namespace compitoTV
{
    internal static class Video
    {
        private static int _canale = 0;

        public static String Canale()
        {
            string link = Directory.GetCurrentDirectory();
            link = link.Replace(@"\bin\Debug\net5.0-windows", "");
            String Link = @"\video\video" + _canale + ".mp4";
            link += Link;
            return System.IO.Path.Combine(link);
        }
        public static int aumCanale()
        {
            if (_canale < 99)
                _canale++;

            return _canale;
        }
        public static int dimCanale()
        {
            if (_canale > 0)
                _canale--;
            return _canale;
        }
    }
}
