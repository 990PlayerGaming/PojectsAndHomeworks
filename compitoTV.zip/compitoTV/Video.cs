﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace compitoTV
{
    internal static class Video
    {
        private static int _canale = 0;

        public static Uri Canale()
        {
            String Link = "";
            Link = "video" + _canale + ".mp4";
            Uri link = new($"pack://application:,,,/video/{Link}", UriKind.RelativeOrAbsolute);
            return link;
        }

        public static void aumCanale()
        {
            if (_canale < 99)
                _canale++;
        }

        public static void dimCanale()
        {
            if (_canale > 0)
                _canale--;
        }
    }
}
